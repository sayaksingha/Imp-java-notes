package in.ineuron;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SbRedisCacheAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
