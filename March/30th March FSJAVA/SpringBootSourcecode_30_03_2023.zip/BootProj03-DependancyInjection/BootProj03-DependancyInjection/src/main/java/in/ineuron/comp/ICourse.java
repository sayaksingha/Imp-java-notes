package in.ineuron.comp;

public interface ICourse {

	public String courseContent();

	public float price();
}
