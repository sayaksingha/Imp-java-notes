package in.ineuron.service;

import in.ineuron.dto.EmployeeDTO;

public interface IEmployeeService {
	public EmployeeDTO calculateHike(EmployeeDTO id);
}
