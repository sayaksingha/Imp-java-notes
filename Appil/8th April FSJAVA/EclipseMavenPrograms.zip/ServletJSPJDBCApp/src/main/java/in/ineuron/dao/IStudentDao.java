package in.ineuron.dao;

import java.util.List;

import in.ineuron.model.StudentBO;

public interface IStudentDao {
	public List<StudentBO> getAllStudents();
}
