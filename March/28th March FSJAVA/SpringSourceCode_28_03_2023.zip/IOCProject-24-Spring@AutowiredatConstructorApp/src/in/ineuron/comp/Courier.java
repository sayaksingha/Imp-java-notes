package in.ineuron.comp;

public interface Courier {
	public String deliver(int oid);
}
