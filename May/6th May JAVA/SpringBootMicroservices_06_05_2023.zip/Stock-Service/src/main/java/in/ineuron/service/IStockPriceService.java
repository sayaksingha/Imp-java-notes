package in.ineuron.service;

public interface IStockPriceService {
	public Double findByCompanyName(String companyName);
}
