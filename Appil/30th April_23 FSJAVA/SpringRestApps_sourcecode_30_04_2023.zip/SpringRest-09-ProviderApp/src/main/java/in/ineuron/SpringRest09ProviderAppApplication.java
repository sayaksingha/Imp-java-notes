package in.ineuron;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringRest09ProviderAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringRest09ProviderAppApplication.class, args);
	}

}
